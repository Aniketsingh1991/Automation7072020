package pages.Automobile;

public class EnterVehicleData {

}
