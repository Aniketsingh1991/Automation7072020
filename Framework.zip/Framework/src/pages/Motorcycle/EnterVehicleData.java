package pages.Motorcycle;

public class EnterVehicleData {

}
