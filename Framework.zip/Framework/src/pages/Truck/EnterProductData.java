package pages.Truck;

public class EnterProductData {

}
