package pages.Camper;

public class EnterVehicleData {

}
