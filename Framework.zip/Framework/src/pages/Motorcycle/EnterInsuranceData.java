package pages.Motorcycle;

public class EnterInsuranceData {

}
