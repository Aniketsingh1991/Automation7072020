package pages.Truck;

public class EnterInsuranceData {

}
