package pages.Truck;

public class SelectPriceOption {

}
